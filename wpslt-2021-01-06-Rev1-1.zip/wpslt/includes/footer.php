<?php
# wp:slt - ver 1.2
# This footer file can be updated as you would any other html file
# just make sure you keep all the div id info in place
# Any other changes you make will be included in every page on your site, so check it carefully
# And remember - you can change it anytime if you like. Keep a backup copy of the original, so you can restore it at will.
?>

<div id="footer">
	<div id="copyright">Copyright &copy; 2021 by Kay Stoner, All Rights Reserved</div>

</div>