<?php
# wp:slt - ver 1.2
# This header file can be updated as you would any other html file
# just make sure you keep all the div id info and spans in place
# You should really only update the links - the href="" and the link text between the <a href=""></a> tags
# Any other changes you make will be included in every page on your site, so check it carefully
# And remember - you can change it anytime if you like. Keep a backup copy of the original, so you can restore it at will.
?>

<div id="header">
	<div  id="wpslt_logo"><a href="../" title="Web Publishing : Simple Little Thing">WP:SLT</a></div>
	<div id="header-links">
		<!-- span><a href="" target="_new">link 2</a></span>
		<span><a href="" target="_new">link 3</a></span -->
		<span><a href="" target="_new"><a href="#content">Skip to content</a></span><!--KEEP THIS LINK/LINE - NEED IT FOR MOBILE-->
		<span><a href="" target="_new">My LinkedIn Profile</a></span>
	</div>
	<div  id="wpslt_description">Web Publishing : Simple Little Thing</div>
</div>