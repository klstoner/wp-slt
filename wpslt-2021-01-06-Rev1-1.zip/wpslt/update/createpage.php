<?php
# Copyright (c) 2021 by Kay Stoner
#
# This file is part of wp:slt
# Version 1.1 - 6 Jan 2021
#
# wp:slt is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# wp:slt is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with wp:slt.  If not, see <https://www.gnu.org/licenses/>.
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>WP:SLT Input</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="keywords" content="page, cms, content, blog, html, web publishing">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../images/favicon.png" />

</head>

<body>

<?php

# first, assign all the variables - only four inputs gives those, plus the filename

$pageTitle = $_POST["pageTitle"];
$fileName = strtolower($pageTitle);
$fileName = str_replace("'","",$fileName);
$fileName = str_replace(",","",$fileName);
$fileName = str_replace(" ","-",$fileName);
$fileName = $fileName . ".php";
$metaDescription = $_POST["metaDescription"];
$metaKeywords = $_POST["metaKeywords"];
$pageContent = $_POST["pageContent"];
$pageContent = str_replace("\n","<br />\n",$pageContent);
$loginPwd = $_POST["loginPwd"];

#echo "page title for title and h1 is: " . $pageTitle . "<br /><br />";
#echo "page filename is: " . $fileName . "<br /><br />";
#echo "meta description is: " . $metaDescription . "<br /><br />";
#echo "meta keywords used for tagging are: " . $metaKeywords . "<br /><br />";
#echo "page content is: ". $pageContent . "<br /><br />";

$sourceTemplate='../templates/update.php';
$targetPage='../content/'.$fileName;

# 1. open the specified template with file_get_contents()
# 2. assign it to a string var

$pageToUpdate = file_get_contents($sourceTemplate);

# 3. replace the values in the string var with the passed values above

#replace values with regexp = title, meta description, meta keywords, h1, page content
	$pageToUpdate = preg_replace('/(<title>).*?(<\/title>)/', '<title>'.$pageTitle.'</title>', $pageToUpdate);
	$pageToUpdate = preg_replace('/(<meta name="description" content=").*?(">)/', '<meta name="description" content="'.$metaDescription.'">', $pageToUpdate);
	$pageToUpdate = preg_replace('/(<meta name="keywords" content=").*?(">)/', '<meta name="keywords" content="'.$metaKeywords.'">', $pageToUpdate);
	$pageToUpdate = preg_replace('/(<h1>).*?(<\/h1>)/', '<h1>'.$pageTitle.'</h1>', $pageToUpdate);
	$pageToUpdate = preg_replace('/(<div id="body_content_text">).*?(<\/div><!-- end body_content_text -->)/', '<div id="body_content_text"><p>'.$pageContent.'</p></div>', $pageToUpdate);

# 4. write the file as the new filename with file_put_contents()

file_put_contents( $targetPage, $pageToUpdate );

#echo $pageToUpdate;

print "<div class='row'><h1>You just created <a href='$targetPage' target='newPage'>$pageTitle</a></h1></div>";


# 5. generate a new toc for all the pages

$tocFile = fopen("../includes/toc.php", "w");

	fwrite($tocFile, "<div id='toc'>\n\t<div id='toc_heading'>Articles</div>\n\t<ul id='toc_list'>\n");

	$dir = "../content/";
	chdir($dir);
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		$article = str_replace(".php","",$filename);
		$articleName = str_replace("-"," ",$article);
		$articleName = ucwords($articleName);
		 fwrite($tocFile, "\t\t<li><a href='$dir$filename'>$articleName</a></li>\n");
	}

	fwrite($tocFile, "\t</ul>\n</div>");
fclose($tocFile);

print <<<EOForm
	<form name="inputForm" id="inputForm" action="update.php" method="post">
	<input type="submit" name="submitButton" id="submitButton" value="Create A New Page" />
	<input type='hidden' name='loginPwd' id='loginPwd' value='$loginPwd' />
	</form>
EOForm;

?>

<div class='row'><h2>Here Are All The Articles You Can Edit</h2>
<form name="inputForm" id="inputForm" action="update.php" method="post">

<ul id="toc_list">
<input type="submit" name="submitButton1" id="submitButton1" value="edit page" class="left" />
<br clear="all">

<?php

$dir = "../content/";
chdir($dir);
array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
foreach($files as $filename)
{
	$article = str_replace(".php","",$filename);
	$articleName = str_replace("-"," ",$article);
	$articleName = ucwords($articleName);
	 echo "<li><input type='radio' name='fileToEdit' id='fileToEdit' value='$filename' /><a href='$dir$filename'>$articleName</a></li>\n";
}
	print "<input type='hidden' name='loginPwd' id='loginPwd' value='$loginPwd' />";
?>

<input type="submit" name="submitButton2" id="submitButton2" value="edit page" class="left" />

</ul>
</div>

</form>

</body>
</html>