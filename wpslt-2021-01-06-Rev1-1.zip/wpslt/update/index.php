<?php
# Copyright (c) 2021 by Kay Stoner
#
# This file is part of wp:slt
# Version 1.1 - 6 Jan 2021
#
# wp:slt is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# wp:slt is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with wp:slt.  If not, see <https://www.gnu.org/licenses/>.
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>WP:SLT Input</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="keywords" content="page, cms, content, blog, html, web publishing">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../images/favicon.png" />

</head>

<body>

<?php include '../includes/header.php';?>

<div id="body_div" class="half">
<div class="row half">

	<h1>WP:SLT - Login</h1>
	<form name="inputForm" id="inputForm" action="update.php" method="post">
	<input type="text" class="inputFormField" name="loginPwd" id="loginPwd" placeholder="password" /><br />
	<input type="submit" name="submitButton" id="submitButton" value="login" />
	</form>
</div>

</div>
<?php include '../includes/footer.php';?>

<script src="../assets/scripts.js"></script>
</body>
</html>