<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Heading Goes Here</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="keywords" content="page, cms, content, blog, html, web publishing">

  <link rel="stylesheet" href="assets/styles.css">
  <link rel="icon" href="images/favicon.png" />

</head>

<body>
<?php include 'includes/header.php';?>

<div class="wide">
<h1>Heading Goes Here</h1>

	<div id="body_content_text" class="wide">
	This is the place where you add information about yourself and your work.<br /><br />
	You can say whatever you like, and you can make the page as large or as small as you like.<br /><br />
	You can use html or PHP or anything else on this page - it is the landing page. Your changes here will not affect anything else on the site, but keep in mind the code below lists all the pages you have.<br /><br />
	You can keep it, or you can comment it out and add something else. It's up to you!<br /><br />

	<?php

	$dir = "content/";
	chdir($dir);
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		$article = str_replace(".php","",$filename);
		$articleName = str_replace("-"," ",$article);
		$articleName = ucwords($articleName);
		 echo "<h2 class='home'><a href='$dir$filename'>$articleName</a><h2>\n";
	}

	?>

	</div>
</div>

<?php include 'includes/footer.php';?>

<script src="assets/scripts.js"></script>
</body>
</html>