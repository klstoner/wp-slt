<div id="toc">

	<div id="toc_heading">Articles</div>

	<ul id="toc_list">

	<?php

	$dir = "../content/";
	chdir($dir);
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		$article = str_replace(".php","",$filename);
		$articleName = str_replace("-"," ",$article);
		$articleName = ucwords($articleName);
		 echo "<li><a href='$dir$filename'>$articleName</a></li>\n";
	}

	?>

	</ul>

</div>