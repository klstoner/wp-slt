<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Gratuitous complexity is a development issue</title>
  <meta name="description" content="Raising the bar for building websites and understanding technology just holds us all back. Here's why.">
  <meta name="keywords" content="web development, technology, learning, skills, development, wealth, earnings, economics, progress">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../assets/favicon.png" />

</head>

<body>
<?php include '../includes/header.php';?>

<div id="body_div">
	<?php include '../includes/toc.php';?>

	<div id="body_content"><a name="content">&nbsp;</a>
	<h1>Gratuitous complexity is a development issue</h1>
		<div id="body_content_text"><p>January 15, 2021<br />
<br />
Once upon a time, back in the days of MySpace and HTML 3.2, when CSS was just getting started, and you could get a little bit of web server space from your AOL account, if you wanted to establish a web presence, you could do that pretty simply. I mean, there was a learning curve, and you couldn't just throw anything out there and expect it to work.<br />
<br />
Okay, so actually you could... and it showed. Ha. Remember that?<br />
<br />
But really, if you wanted to learn how to build websites, you could do it by yourself. And you could learn to do it really well. By yourself. We didn't have all the platforms we have now. We didn't have the frameworks. We didn't have the tons of different technical layers we have now. And while security was an issue in some cases, it wasn't the mammoth problem it is, now.<br />
<br />
But we grew up.<br />
<br />
Well, we <b>grew</b>, anyway...<br />
<br />
And we could just go about our business and build stuff.<br />
<br />
Of course, now things are way more complicated. And I'd suggest that in some cases, the complexity is gratuitous - as in, it mainly serves the people creating it. It's like a kind of hazing feature that blocks people from participating, unless and until they know what they're really doing in the technology.<br />
<br />
No, it's not that... because even if you don't know how to run it at ninja-level, you can still put the pieces together and create something. A WordPress site. A Blogger or Typepad blog. Or any of the other various platforms that are so plentiful, these days. You can do it. You might not be able to do it well, but you can do it.<br />
<br />
And that, to me, is an issue. Because if you're going to build something, don't you want it to be really cool and in good working order? Don't you want it to be secure and look good and be something you can take pride in? Most of really do take pride in our work. We want to be well-regarded. We want to be able to take credit for what we've done, not take the blame.<br />
<br />
But I digress. Here's the thing. With so many options and so many capabilities, it feels sometimes like we've just gone off the deep end with trying different things and putting stuff out there that we think will be fantastic and all that. Maybe it is. Or maybe we don't understand that the thing we just built isn't nearly as wondrous as we think it is. But we're still super pleased (I think the word is "chuffed") that we did it.<br />
<br />
And all the complexity that results from all of that is blocking us. It's blocking us as people, it's blocking us as professionals, it's bogging down the web development world and making things a hell of a lot more complicated than they need to be.<br />
<br />
Which makes it harder to learn new skills. It sometimes requires we take lots of courses and complete certifications and do bootcamps and all that. Or we just think it requires that. It locks us into an educational cycle that, frankly, blocks us from doing the kinds of things we really need to be doing instead. Like doing the actual work. Like building actual things. Like getting our hands dirty doing what we want to do, the way we want to do it. Or the way we'd like to see it done, versus how it's being done.<br />
<br />
Stuff being overly complicated is an issue. It slows us down. It keeps us from getting up and running quickly and effectively. It convinces us that we don't know enough, when we actually do know enough to get started... so that we can continue to learn, once we do start.<br />
<br />
Gratuitous complexity is a development issue - for the people doing it, for the technologies we're building, and for the economy, too.<br />
<br />
But hey - why curse the darkness, when you can light a candle?<br />
<br />
Why indeed?</p></div><!-- end body_content_text -->
	</div>

</div>

<?php include '../includes/footer.php';?>

</body>
</html>