<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Sample Page</title>
  <meta name="description" content="This is a sample page with some of the content included, so you can see how to start">
  <meta name="keywords" content="publishing, cms, diy, simplicity">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../assets/favicon.png" />

</head>

<body>
<?php include '../includes/header.php';?>

<div id="body_div">
	<?php include '../includes/toc.php';?>

	<div id="body_content"><a name="content">&nbsp;</a>
	<h1>Sample Page</h1>
		<div id="body_content_text"><p>Here's where you start. It's pretty simple, really.<br />
<br />
Just type in what you've got to say. You can add html as you please - within reason.  Some of the html features don't work yet - and they may never work, because, well, I want to keep it simple.<br />
<br />
And if we all start creating complex pages with tables, etc., then it won't be simple anymore.<br />
<br />
We'll just be back to where we started.<br />
<br />
Who wants that? Not I!</p></div><!-- end body_content_text -->
	</div>

</div>

<?php include '../includes/footer.php';?>

</body>
</html>