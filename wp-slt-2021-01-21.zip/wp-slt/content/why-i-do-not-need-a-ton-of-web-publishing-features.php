<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Why I do not need a ton of web publishing features</title>
  <meta name="description" content="A lot of content management systems have a slew of features. I don't need them. Here's why.">
  <meta name="keywords" content="web publishing, cms, content management, complexity, simplicity, writing, blogging">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../assets/favicon.png" />

</head>

<body>
<?php include '../includes/header.php';?>

<div id="body_div">
	<?php include '../includes/toc.php';?>

	<div id="body_content"><a name="content">&nbsp;</a>
	<h1>Why I do not need a ton of web publishing features</h1>
		<div id="body_content_text"><p>January 17, 2021<br />
<br />
As the new year continues to advance, I think about how wild it's all become. I mean... seriously wild.<br />
<br />
It's all gotten so <b>complicated</b>. It's hard to keep track, anymore, about who's doing what, who's allowed to do what, who shouldn't be doing what, and what, if anything, should happen to someone who does something they really shouldn't be doing.<br />
<br />
And as I think about my life, I'd love to get some more simplicity in it. I truly would.<br />
<br />
Especially with regard to my online publishing.<br />
<br />
Okay, so I have a bunch of WordPress instances. More than I care to admit. I have a bunch of WordPress.org sites, as well as WordPress.com sites. I use WP for a handful of membership sites I run, as well as some educational stuff. Plus, I have my personal blog. Okay, blog<b>s</b>. I told you I have more than I care to admit. When I was first setting them up, it was fun! I love to install and configure stuff. Yeah, I'm that kind of glutton for punishment. And the idea that I can have <em>all these differen features</em> at my fingertips... well, that's just intoxicating for me.<br />
<br />
But like many other kinds of intoxication, it gets to be a bit much, after a while. And I've found myself doing more fiddling with features and plugins and settings, over the years, than I'd like. My writing time has been co-opted by my fiddling time.<br />
<br />
And I want that to stop. Especially for this year.<br />
<br />
I guess maybe it's a sort of New Year's resolution for me...? To simplify my writing process, to concentrate on the essentials, rather than getting caught up in a lot of (let's face it) luxurious configuration experiments that may or may not be essential for the functioning of my site.<br />
<br />
Cut out the unnecessary stuff. Trim the unneeded extras. Just get down to barebones and let the thing be about the writing, not the coding.<br />
<br />
It feels pretty good, too. I have to admit, there's a kind of "cold turkey" feel to this, as I write and instinctively look for those buttons that will let me format a bunch of highlighted words with a single click. At the same time, though, I'm perfectly capable of putting in some <code><b></b></code> tags around my text.<br />
<br />
And you know what? Everybody else is, too.<br />
<br />
So, as I get this little publishing system off the ground and work with it, myself, I'm excited. It's a new year. This is a new platform. It's built on ~25 years of web publishing and coding experience. It makes me happy, and I think it will improve the lives of others, too.<br />
<br />
That's really what matters most, I think.<br />
</p></div><!-- end body_content_text -->
	</div>

</div>

<?php include '../includes/footer.php';?>

</body>
</html>