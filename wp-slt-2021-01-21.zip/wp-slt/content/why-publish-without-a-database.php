<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Why publish without a database?</title>
  <meta name="description" content="On the drawbacks of database-driven content management systems, and the benefits of publishing a site without a back-end database.">
  <meta name="keywords" content="cms, content management, database, PHP, HTML, CSS, website, blog, publishing, web publishing">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../assets/favicon.png" />

</head>

<body>
<?php include '../includes/header.php';?>

<div id="body_div">
	<?php include '../includes/toc.php';?>

	<div id="body_content"><a name="content">&nbsp;</a>
	<h1>Why publish without a database?</h1>
		<div id="body_content_text"><p>January 14, 2021<br />
<br />
After decades of publishing online (since 1995) and almost as long working with content management systems, I’ve had a couple of recurring questions that just won’t go away.<br />
<ol><br />
<li>Mainly, do I actually need a database in order to do content management for a website? </li><br />
<li>And secondly, how can I publish online without a database, including creating and updating pages, while not having to do all the html by hand?</li><br />
</ol><br />
<h2>Question 1: Do I actually need a database in order to do content management for a website?</h2><br />
In the case of e-commerce, where there are many different items which must display dynamically or which change from time to time, a content management system with a database behind it makes total sense. In that case, you need to be able to update, display, filter your site elements, etc. You need to have control over individual moving pieces, because, well, the site is dynamic. It doesn’t stay the same.<br />
<br />
But in the case of a static website, were you're literally just looking at web pages which sit there in the same state until somebody comes along and updates some of the text, I’m not so sure. If a page is static - and in fact the whole design of the site is static - and you have no need to dynamically generate content or functionality on a regular basis, I’m not sure why I'd need a database.<br />
<br />
Of course, if you <b>have</b> modularized your content and you want to render pieces of it in different ways on different parts of the site, it totally makes sense to have things broken out as separate objects in the back end. There's nothing like being able to mix-and-match at will, so you can render a different experience, based on varying visitor needs. Someone stopping by just to browse and get high-level info gets one experience, while a site member gets something more in-depth, and someone who's a premium member gets all the bells and whistles.<br />
<br />
But if everything is just sitting there looking at you on the screen and it will never change, regardless of who's looking at it… I don’t actually see the need for a database.<br />
<br />
Personally, I think that databases for content management are attractive to developers who use source control a lot. In the case of source control, you definitely want to keep all the versions of your code so you can revert back to them in the future, if something gets messed up. It's your safety net. It keeps you from getting in trouble and staying there. You need that kind of granular functionality to dig yourself out of a hole, with all the distinct pieces you're coding up tracked and restorable in their original, non-effed-up state.<br />
<br />
That solves a development problem. It doesn't solve a writer's problem. I mean, think about how many times we update what we write, fixing typos, changing paragraphs, moving things around from one place to the next. Why would we need to retain prior versions before we put in Oxford commas? Updates and rewrites are a frequent part of any drafting and polishing process. And unless there's a legal requirement to retain prior versions of a document, there’s no reason that we should be storing multiple versions of essentially the same article with just a few changes made. Even if there are a lot of changes made, why would we need to keep the old version? Especially then, we probably won't.<br />
<br />
I know I don't.<br />
<br />
Anyway, if you do need to keep the old version, you can simply make a copy of that in your archives folder and leave it there, right? A lot of us (me included) draft our most valuable work in a word processor and then copy and paste it into a blog or site. And how many of us have “edit tracking” turned on when we do? We don't. Because we don't need it.<br />
<br />
So the bottom line is, for the purposes of building and rendering and updating static websites which have nothing dynamic about them, a database is overkill.<br />
<br />
It’s not only overkill in terms of functionality, either. As a matter of fact, databases and the action of reading from them, updating them, writing to them, etc. - it's all overkill. It takes processing power to do all of that. I've heard people protest that it doesn't take that much, but I disagree in principle as well as in the details - it takes more work and energy and resources than not using a database at all. Even if it takes just a little bit, multiply that by how many db-driven blogs are out there, and it stops being nominal.<br />
<br />
Even before you get into the action of reading, writing, deleting, updating, there's additional work added to setting things up. You have to go through the process of building it all out - and making sure that is properly designed before it’s built - as well as keeping it optimized. Databases are a whole other thing, compared to static web pages, and they are far beyond the understanding of most people who just want to blog.<br />
<br />
Even for the people who are well-versed in them, designing, building, maintaining, and generally managing databases can turn into a full-time job. And that job can very easily pull you away from the other things which are actually more important to a site itself, such as mobile responsiveness, SEO, and user-friendly design.<br />
<br />
In terms of energy, unless you’re working with a platform that is mature, time-tested, and well-supported, doing all the database stuff can be demanding. But even more than that, for me, as we see exponential growth in power requirements for all the computing that we’re doing, any gratuitous use of resources, whether it is fossil fuel, human, processing power, or general computing, seems irresponsible.<br />
<br />
People may shrug their shoulders and say, “Well it’s no big deal, we have it all figured out and we know how to do it pretty well, thank you very much.” They may protest that we haven’t had that many problems yet, so what’s the issue? Or they may just dismiss this economic imperative as being parsimonious. In tech, the concepts of efficiency and economy can be heresies against our ethos of ever expanding power and consumption, which signals “sophistication” to many. Trying to put the brakes on our headlong chase after as much power as we can get, so we can drive as many initiatives as we can think of, is far from popular. In fact, if anything, it’s fairly scoff-worthy, since there tends to be this prevailing belief that rather than curtailing our resource use, we should be finding new ways to create new resources for ourselves. We don't want to deprive ourselves of progress, after all.<br />
<br />
But as we hurtle forward into a future where our power demands exponentially increase seemingly by the day, perhaps this approach to updating websites without a database - and therefore incurring less overhead all across-the-board - has a place in the grand scheme of things.<br />
<br />
Even beyond the computing power concerns, there’s a human element, as well. Database-driven websites are by their very nature more complex than static websites. Blogging platforms like Blogger and WordPress and all the others out there (which also can be used for building full-featured websites), promise accessibility to every day people who just want to publish something. Unfortunately, because there are so many features and options built in to the back-end, everyone needs to go in and do some sort of configuration to make sure the system has what it needs. Essentially, we serve the machine, not the other way around.<br />
<br />
It becomes just a little less about writing and publishing, and more about fiddling with the system that makes it all possible.<br />
<br />
<h2>Question #2: How can I publish online without a database, including creating and updating pages, while not having to do all the html by hand?</h2><br />
Given my concerns above, this is what I'm doing here. This is a site (or call it a blog) that has content management which has no database behind it.<br />
<br />
By introducing a db-free solution for creating and updating web pages, I've removed any obligation to a database. This frees me up to concentrate on what matters most to me, and the whole reason I have this site, to begin with - creating and publishing and updating web-based content.<br />
<br />
You may argue, “But then how do you ensure that your site's pages are consistent, that they are well-formed, that they have all the elements that they need for things like SEO and responsiveness?” That's easy: use templates. By coding up a master page in the proper way and then writing to that same page and saving it as separate pages over and over, consistency all across the site can be achieved and preserved. And Google likes it, too. Especially when the HTML is well-formed and semantically coherent.<br />
<br />
In a database-less system, the updating is defined not by abstracted fields in a separate repository, but by proper tagging within the HTML template itself. And with properly formed HTML with appropriate CSS id=”” references, demarcating what exactly should be changed on each page is a relatively simple matter.<br />
<br />
Furthermore, because it's the code and the HTML tags in the page that define what gets updated, many different templates with different designs and different elements and different components can be created and leveraged. That allows a great deal of flexibility in the overall page design. It also makes it quick and easy to update the design of the site, either by swapping out the stylesheet or by regenerating the content with an updated template. And because the system I've built uses PHP includes for common page elements, such as the header, the footer, and the table of contents, updating those elements globally is straightforward and simple.<br />
<br />
This site is very basic, I know, and that's by design. I literally just want to publish without having to fiddle with design features. I can always tweak the CSS later, if I like. I can even come up with a different template, if I like. Or multiples. Whatever I want. The whole point is, it's as simple (or as complex) as I choose, and I'm not beholden to someone else's architecture or idea of what constitutes good technical design. I can do what I please, and that's fine with me.<br />
<br />
Essentially, the system relies on the fundamentals of HTML and a deep understanding of it to fully exploit its features and capabilities for everyone’s benefit. Not only is the system much easier to use, but it’s also faster and easier to set up, maintain, and configure. It's also extensible, and anyone with a solid grasp of basic PHP could update their version with new features and functionality. Best of all, you don’t have to wrangle with a database that may or may not need to be updated when you make a significant change to your website. It's static. And even the pieces that are dynamic (some site elements which write out directory contents as tables of contents or lists of pages) really are static, once they write to the page.<br />
<br />
As a longtime WordPress user, this relieves me of the burden of plug-ins. A number of plug-ins have been created to offset issues that WordPress itself introduces, but with properly formatted HTML, optimized images, and well written scripts and CSS files, I can actually produce a faster, great-looking, full-featured website with a lot less hassle and a lot better performance than a WordPress instance.<br />
<br />
Ultimately this all comes back to a conclusion I reached back in 1999, when I realized that the web itself is a content repository. There’s really no need to have a database to store all of the continent for you, solely for the purpose of updating it. If you already have a means by which to ingest those HTML files and update them through a form, you're golden.<br />
<br />
We’ve been doing things the hard way, low these many years. Isn’t it time to try something different?</p></div><!-- end body_content_text -->
	</div>

</div>

<?php include '../includes/footer.php';?>

</body>
</html>