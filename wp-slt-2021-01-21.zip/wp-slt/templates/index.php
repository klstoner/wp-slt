<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Page Title</title>
  <meta name="description" content="Meta description of this page - potentially used for Google preview in search results">
  <meta name="keywords" content="keywords, key phrases, each distinct one separated by commas - to be used for displaying lists of categorized content later">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../assets/favicon.png" />

</head>

<body>
<?php include '../includes/header.php';?>

<div id="body_div">
	<?php include '../includes/toc.php';?>

	<div id="body_content"><a name="content">&nbsp;</a>
	<h1>Heading</h1>
		<div id="body_content_text"></div><!-- end body_content_text -->
	</div>

</div>

<?php include '../includes/footer.php';?>

</body>
</html>