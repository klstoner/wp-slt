<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>wp:slt - web publishing : simple little thing</title>
  <meta name="description" content="This is a simple web publishing utility that lets you just create web pages without much fuss. Blog posts, simple sites, even more complex ones can be built with wp:slt.">
  <meta name="keywords" content="web dev, front-end development, web, projects, PHP, HTML, CSS, JavaScript, page, CMS, content management, databases, blog, html, web publishing">

  <link rel="stylesheet" href="assets/styles.css">
  <link rel="icon" href="assets/favicon.png" />

</head>

<body>
<?php include 'includes/header.php';?>

<div class="wide">
<h1>wp:slt - a simple web publishing utility that lets you just create web pages without much fuss</h1>

	<div id="body_content_text" class="wide">
	As we continue to evolve the web and our online techologies, we tend to be more complex, rather than less. That's for a whole host of reasons, but all rationalizing aside, web publishing has become kind of a hot mess. I mean, even simple things like a basic page, can be hella difficult to create. And if you don't have a bootcamp background in all sorts of stuff, or you don't invest however many hours you need to come up with your own WordPress instance, you kind of get left behind.<br /><br />

	That's too bad, because I'm one of those people who got into building web sites all because I loved the idea of publishing. And it makes me sad :( that more people can't easily experience the euphoria that overwhelmed me in 1995, when I realized that I could actually publish my own words by myself on my own terms. And nobody could stop me.<br /><br />

	That was revolutionary. And I want others to have the same access to that amazement and, well, giddiness, that used to consume me as I learned to put together web pages and saw my words come to life on the screen.<br /><br />

	This landing page is really the only html (reader-facing) page in the system that isn't updatable via the CMS functionality. But that doesn't have to be prohibitive, because the html here is not that hard to figure out, and anyway, if you mess up, you can always start over with a fresh copy of this page. Or, you can just strip out the top section before the h2 heading below and just let the system display a list of all the pages you've created.<br /><br />

	I'll be the first to admit, this is not the most elegantly styled site I could have built for starters. But it doesn't have to stay that way for you. wp:slt lets you customize your CSS to your heart's content, and you can even build other templates to use, if this design really offends you. Heck, within certain very minimal parameters, you can pretty much do whatever you like.<br /><br />

	And it won't stop you from publishing simply, easily, quickly, without needing a PhD in quantum computing.<br /><br />

	<center><h2>Here's a listing of what's on this site:</h2></center>
	<?php

	$dir = "content/";
	chdir($dir);
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		$article = str_replace(".php","",$filename);
		$articleName = str_replace("-"," ",$article);
		$articleName = ucwords($articleName);
		 echo "<h2 class='home'><a href='$dir$filename'>$articleName</a><h2>\n";
	}

	?>

	</div>
</div>

<?php include 'includes/footer.php';?>

</body>
</html>