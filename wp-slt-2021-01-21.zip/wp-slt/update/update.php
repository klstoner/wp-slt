<?php
# Copyright (c) 2021 by Kay Stoner
#
# This file is part of wp:slt
# Version 1.21 - 21 Jan 2021
#
# wp:slt is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# wp:slt is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with wp:slt.  If not, see <https://www.gnu.org/licenses/>.

# check for referrer and password - if none, then redirect back to login page
	$referer = $_SERVER['HTTP_REFERER'];
	print "<!-- page referrer is " . $referer . " -->";

# match referer on the /update/ directory so we make sure they come from within the system
	$loginReferer = preg_match("/\/update\//",$referer);

# vvvvv Define the system password below vvvvv
		$loginSystemPwd = "1234poiu";

# Make sure the login password is set, so we can check it against the system password
	if ( $loginReferer && isset($_POST["loginPwd"])) {
		print "<!-- br />came from login<br / -->";
		$loginPwd = $_POST["loginPwd"];

# Pull the page content id to update from the /includes/ids.txt value
		ob_start();
		require_once('../includes/ids.txt');
		$pageContentID = ob_get_clean();

# if the login pwd does NOT match the system pwd, send them back to the login page
		if ($loginPwd != $loginSystemPwd) {
#			print "<br />login password is $loginPwd<br />";
#			print "<br />login system password is $loginSystemPwd<br />";
#			print "<br />login password doesn't match loginSystemPwd<br />";
			#header('location: index.php'); // cannot reset header - already done once - use js redirect
			$URL="index.php";
			echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

# if DOES match, then proceed (and have lines to print details for testing
		} else {
#			print "<br />login password is $loginPwd<br />";
#			print "<br />login system password is $loginSystemPwd<br />";
#			print "<br />login password DOES loginSystemPwd<br />";
			#header('location: index.php');
		}

# if the login is NOT okay and they do NOT come from /update/ use js redirect to send back to login page
	} else {
#		print "<br />login password is $loginPwd<br />";
#		print "<br />login system password is $loginSystemPwd<br />";
#		print "<br />login password DOES loginSystemPwd<br />";
			$URL="index.php";
			echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
	}

?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>WP:SLT Input</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="keywords" content="page, cms, content, blog, html, web publishing">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../images/favicon.png" />

</head>

<body>

<?php include '../includes/header.php'; ?>

<div id="body_div" class="wide">

<div id="toc">

	<div id="toc_heading">Articles to Edit</div>
	<form name="inputForm" id="inputForm" action="update.php" method="post">
	<input type="submit" name="submitButton1" id="submitButton1" value="edit page below" />
	<ul id="toc_list">

	<?php
	# set directory for pages to /content/ - this may also be set with a parameter in a future iteration
	# or we could even make it a select that lets you write to whatever directory you want to
	$dir = "../content/";

	# change to the $dir set
	chdir($dir);

	# pull all the content from the directory with a loop - iterate through the dir and write out all the names
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		# Use the filename with .php on the end as the article link text
		$article = str_replace(".php","",$filename);

		# replace all the dashes with spaces
		$articleName = str_replace("-"," ",$article);

		# also uppercase all the words, even though it is not ideal formatting
		$articleName = ucwords($articleName);

		# print out the li with the article link and title
		 print "<li><input type='radio' name='fileToEdit' id='fileToEdit' value='$filename' /><a href='$dir$filename'>$articleName</a></li>\n";
	}

	# print the hidden field for $loginPwd, so we can pass it to createpage.php
	print "<input type='hidden' name='loginPwd' id='loginPwd' value='$loginPwd' />";
	?>

	</ul>

	<input type="submit" name="submitButton2" id="submitButton2" value="edit page above" />
	</form>

</div>

<div id="body_content" class="wide">
<a name="content">&nbsp;</a><br />

<?php

# check if $fileToEdit is set - if it is not, just print the form to create a new page

if(!isset($_POST["fileToEdit"])) { // not editing a file - creating a new one

$createEdit = "create";
# print "about to $createEdit a page";

print <<<EOForm
	<h1>WP:SLT - Create A New Page</h1>
	<form name="inputForm" id="inputForm" action="createpage.php" method="post">
	<input type="text" class="inputFormField" name="pageTitle" id="pageTitle" required placeholder="Page Title" /><br />
	<input type="text" class="inputFormField" name="metaDescription" id="metaDescription" required placeholder="Description" /><br />
	<input type="text" class="inputFormField" name="metaKeywords" id="metaKeywords" required placeholder="Keywords" /><br />
EOForm;

	#print the form field for the ID in ids.txt
	  print "\n\t<textarea class='inputFormField' name='pageContent' id='pageContent'></textarea><br /><br />";

print <<<EOForm1
	<input type="submit" name="submitButton" id="submitButton" value="create page" />
	<input type='hidden' name='loginPwd' id='loginPwd' value='$loginPwd' />
	<input type='hidden' name='createEdit' id='createEdit' value='$createEdit' />
	</form>
EOForm1;

# If file is set to Edit, then edit the page it like so:

} else {

	$createEdit = "edit";
#	print "about to $createEdit a page";

	# get the filename passed
	$fileToEdit = $_POST["fileToEdit"];

	# set the target page to the dir and the filetoedit values
	$targetPage = $dir.$fileToEdit;

	# 1. open the specified template with file_get_contents()
	# 2. assign it to a string var

	$pageToUpdate = file_get_contents($targetPage);

	# 3. get the values needed for the inputs - Page Title, Meta Description, Meta Keywords, Page Content
	# In these instances, we get the entire contents of the page to edit, and we split it at the opening tag
	# Then we grab the second half of the piece and strip off the closing tag
	# What we have left is the actual content of that element.
	# This is actually easier and cleaner than having to loop through each line of the file in question.
	# There is no dealing with multi-line values - it's subtractive, rather than additive, and it's more accurate, I think

		$pageTitlePiece = explode('<title>', $pageToUpdate);
		$pageTitleStart = $pageTitlePiece[1]; #echo "pageTitleStart is $pageTitleStart <hr />";
		$pageTitleEnd = explode('</title>', $pageTitleStart); #echo "pageTitleEnd is $pageTitleEnd<hr />";
		$pageTitle = $pageTitleEnd[0]; #echo "pageTitle is $pageTitle<hr />";

		$metaDescriptionPiece = explode('<meta name="description" content="', $pageToUpdate);
		$metaDescriptionStart = $metaDescriptionPiece[1]; #echo "metaDescriptionStart is $metaDescriptionStart <hr />";
		$metaDescriptionEnd = explode('">', $metaDescriptionStart); #echo "metaDescriptionEnd is $metaDescriptionEnd<hr />";
		$metaDescription = $metaDescriptionEnd[0]; #echo "metaDescription is $metaDescription<hr />";

		$metaKeywordsPiece = explode('<meta name="keywords" content="', $pageToUpdate);
		$metaKeywordsStart = $metaKeywordsPiece[1]; #echo "metaKeywordsStart is $metaKeywordsStart <hr />";
		$metaKeywordsEnd = explode('">', $metaKeywordsStart); #echo "metaKeywordsEnd is $metaKeywordsEnd<hr />";
		$metaKeywords = $metaKeywordsEnd[0]; #echo "metaKeywords is $metaKeywords<hr />";

		# we need to set the opening and closing tags of the page content section so we can split them and tidy up
		$pageContentSectionStart = "<div id=\"".$pageContentID."\">";
		$pageContentSectionEnd = "</div><!-- end ".$pageContentID." -->";
		$pageContentPiece = explode($pageContentSectionStart, $pageToUpdate);
		$pageContentStart = $pageContentPiece[1]; #echo "pageContentStart is $pageContentStart <hr />";
		$pageContentEnd = explode($pageContentSectionEnd, $pageContentStart); #echo "pageContentEnd is $pageContentEnd<hr />";
		$pageContent = $pageContentEnd[0]; #echo "pageContent is $pageContent<hr />";
		$pageContent = str_replace("<br />\n", "", $pageContent);
		$pageContent = str_replace("<p>", "", $pageContent);
		$pageContent = str_replace("</p>", "", $pageContent);

	# 4. write out the input form with the values included and make sure it's all writing to the proper page (overwriting the original)

	print <<<EOForm2
		<h1>WP:SLT - Update Your Page</h1>
		<form name="inputForm" id="inputForm" action="createpage.php" method="post">
		<input type="text" class="inputFormField" name="pageTitle" id="pageTitle" required value="$pageTitle" /><br />
		<input type="text" class="inputFormField" name="metaDescription" id="metaDescription" required value="$metaDescription" /><br />
		<input type="text" class="inputFormField" name="metaKeywords" id="metaKeywords" required value="$metaKeywords" /><br />
		<textarea class="inputFormField" name="pageContent" id="pageContent">$pageContent</textarea><br />
		<input type='hidden' name='loginPwd' id='loginPwd' value='$loginPwd' />
		<input type='hidden' name='createEdit' id='createEdit' value='$createEdit' />
		<input type="submit" name="submitButton" id="submitButton" value="update this page" />
		</form>
EOForm2;
}

?>

</div>
</div>
<?php include '../includes/footer.php';?>

</body>
</html>