<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>WP:SLT - WebPublishing : Simple Little Thing</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="keywords" content="page, cms, content, blog, html, web publishing">

  <link rel="stylesheet" href="assets/styles.css">
  <link rel="icon" href="images/favicon.png" />

</head>

<body>
<?php include 'includes/header.php';?>

<div class="wide">
<h1>WP:SLT - WebPublishing : Simple Little Thing</h1>

	<div id="body_content_text" class="wide">
	This is my new space where I'm posting about my technology work. I've built a bunch of stuff in the past, and it brings me much joy. <br /><br />
	I continue to do so because, well, it still brings me much joy.<br /><br />
	Just as writing and creating art brings some people happiness, coding does the trick for me.<br /><br />
	Here's what I've been up to, lo these many years...<br /><br />

	<?php

	$dir = "content/";
	chdir($dir);
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		$article = str_replace(".php","",$filename);
		$articleName = str_replace("-"," ",$article);
		$articleName = ucwords($articleName);
		 echo "<h2 class='home'><a href='$dir$filename'>$articleName</a><h2>\n";
	}

	?>

	</div>
</div>

<?php include 'includes/footer.php';?>

<script src="assets/scripts.js"></script>
</body>
</html>