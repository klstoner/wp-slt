<?php
# Copyright (c) 2021 by Kay Stoner
#
# This file is part of wp:slt
# Version 1.0 - 5 Jan 2021
#
# wp:slt is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# wp:slt is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with wp:slt.  If not, see <https://www.gnu.org/licenses/>.
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>WP:SLT Input</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="keywords" content="page, cms, content, blog, html, web publishing">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../images/favicon.png" />

</head>

<body>

<?php include '../includes/header.php';?>

<div id="body_div" class="wide">

<div id="toc">

	<div id="toc_heading">Articles to Edit</div>
	<form name="inputForm" id="inputForm" action="index.php" method="post">
	<input type="submit" name="submitButton1" id="submitButton1" value="edit page below" />
	<ul id="toc_list">

	<?php

	$dir = "../content/";
	chdir($dir);
	array_multisort(array_map('filemtime', ($files = glob("*.*"))), SORT_DESC, $files);
	foreach($files as $filename)
	{
		$article = str_replace(".php","",$filename);
		$articleName = str_replace("-"," ",$article);
		$articleName = ucwords($articleName);
		 echo "<li><input type='radio' name='fileToEdit' id='fileToEdit' value='$filename' /><a href='$dir$filename'>$articleName</a></li>\n";
	}

	?>

	</ul>

	<input type="submit" name="submitButton2" id="submitButton2" value="edit page above" />
	</form>

</div>

<div id="body_content" class="wide">
<a name="content">&nbsp;</a><br />

<?php

# check if $fileToEdit is set - if it is not, just print this:

if(!isset($_POST["fileToEdit"])) {

print <<<EOForm
	<h1>WP:SLT - Create A New Page</h1>
	<form name="inputForm" id="inputForm" action="createpage.php" method="post">
	<input type="text" class="inputFormField" name="pageTitle" id="pageTitle" placeholder="Page Title" /><br />
	<input type="text" class="inputFormField" name="metaDescription" id="metaDescription" placeholder="Description" /><br />
	<input type="text" class="inputFormField" name="metaKeywords" id="metaKeywords" placeholder="Keywords" /><br />
	<textarea class="inputFormField" name="pageContent" id="pageContent"></textarea><br />
	<input type="submit" name="submitButton" id="submitButton" value="create page" />
	</form>
EOForm;

} else {

	$fileToEdit = $_POST["fileToEdit"];

	# echo "need form here";

	$targetPage = '../content/'.$fileToEdit;

	# 1. open the specified template with file_get_contents()
	# 2. assign it to a string var

	$pageToUpdate = file_get_contents($targetPage);

	# 3. get the values needed for the inputs - Page Title, Meta Description, Meta Keywords, Page Content

		$pageTitlePiece = explode('<title>', $pageToUpdate);
		$pageTitleStart = $pageTitlePiece[1]; #echo "pageTitleStart is $pageTitleStart <hr />";
		$pageTitleEnd = explode('</title>', $pageTitleStart); #echo "pageTitleEnd is $pageTitleEnd<hr />";
		$pageTitle = $pageTitleEnd[0]; #echo "pageTitle is $pageTitle<hr />";

		$metaDescriptionPiece = explode('<meta name="description" content="', $pageToUpdate);
		$metaDescriptionStart = $metaDescriptionPiece[1]; #echo "metaDescriptionStart is $metaDescriptionStart <hr />";
		$metaDescriptionEnd = explode('">', $metaDescriptionStart); #echo "metaDescriptionEnd is $metaDescriptionEnd<hr />";
		$metaDescription = $metaDescriptionEnd[0]; #echo "metaDescription is $metaDescription<hr />";

		$metaKeywordsPiece = explode('<meta name="keywords" content="', $pageToUpdate);
		$metaKeywordsStart = $metaKeywordsPiece[1]; #echo "metaKeywordsStart is $metaKeywordsStart <hr />";
		$metaKeywordsEnd = explode('">', $metaKeywordsStart); #echo "metaKeywordsEnd is $metaKeywordsEnd<hr />";
		$metaKeywords = $metaKeywordsEnd[0]; #echo "metaKeywords is $metaKeywords<hr />";

		$pageContentPiece = explode('<div id="body_content_text">', $pageToUpdate);
		$pageContentStart = $pageContentPiece[1]; #echo "pageContentStart is $pageContentStart <hr />";
		$pageContentEnd = explode('</div>', $pageContentStart); #echo "pageContentEnd is $pageContentEnd<hr />";
		$pageContent = $pageContentEnd[0]; #echo "pageContent is $pageContent<hr />";
		$pageContent = str_replace("<br />\n", "", $pageContent);
		$pageContent = str_replace("<p>", "", $pageContent);
		$pageContent = str_replace("</p>", "", $pageContent);

#		$metaDescription = preg_match('/(<meta name="description" content=").*?(">)/', $pageToUpdate);
#		$metaKeywords = preg_match('/(<meta name="keywords" content=").*?(">)/', $pageToUpdate);
#		$pageContent = preg_match('/(<div id="body_content_text">).*?(<\/div>)/', $pageToUpdate);

	# 4. write out the input form with the values included and make sure it's all writing to the proper page (overwriting the original)

	print <<<EOForm2
		<h1>WP:SLT - Update Your Page</h1>
		<form name="inputForm" id="inputForm" action="createpage.php" method="post">
		<input type="text" class="inputFormField" name="pageTitle" id="pageTitle" value="$pageTitle" /><br />
		<input type="text" class="inputFormField" name="metaDescription" id="metaDescription" value="$metaDescription" /><br />
		<input type="text" class="inputFormField" name="metaKeywords" id="metaKeywords" value="$metaKeywords" /><br />
		<textarea class="inputFormField" name="pageContent" id="pageContent">$pageContent</textarea><br />
		<input type="submit" name="submitButton" id="submitButton" value="update this page" />
		</form>
EOForm2;
}

?>

</div>
</div>
<?php include '../includes/footer.php';?>



<script src="../assets/scripts.js"></script>
</body>
</html>