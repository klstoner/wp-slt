<div id="footer">
	<div id="copyright">Copyright &copy; 2021 by Kay Stoner, All Rights Reserved</div>

</div>