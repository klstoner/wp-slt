<div id='toc'>
	<div id='toc_heading'>Articles</div>
	<ul id='toc_list'>
		<li><a href='../content/sample-page.php'>Sample Page</a></li>
	</ul>
</div>