<div id="header">
	<div  id="wpslt_logo"><a href="../" title="Web Publishing : Simple Little Thing">WP:SLT</a></div>
	<div id="header-links">
		<!-- span><a href="" target="_new">link 2</a></span>
		<span><a href="" target="_new">link 3</a></span -->
		<span><a href="" target="_new"><a href="#content">Skip to content</a></a></span>
		<span><a href="https://www.linkedin.com/in/kaystoner/" target="_new">My LinkedIn Profile</a></span>
	</div>
	<div  id="wpslt_description">Web Publishing : Simple Little Thing</div>
</div>