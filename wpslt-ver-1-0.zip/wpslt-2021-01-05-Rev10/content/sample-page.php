<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Sample Page</title>
  <meta name="description" content="This is a sample page for starters">
  <meta name="keywords" content="sample, page, keywords, template, text">

  <link rel="stylesheet" href="../assets/styles.css">
  <link rel="icon" href="../images/favicon.png" />

</head>

<body>
<?php include '../includes/header.php';?>

<div id="body_div">
	<?php include '../includes/toc.php';?>

	<div id="body_content"><a name="content">&nbsp;</a>
	<h1>Sample Page</h1>
		<div id="body_content_text"><p>This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.<br />
<br />
This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.<br />
<br />
This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.<br />
<br />
This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.<br />
<br />
This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.<br />
<br />
This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.<br />
<br />
This sample page is just a placeholder. You can update it or remove it. After you have published a page for your site, you should remove this.</p></div>
	</div>

</div>

<?php include '../includes/footer.php';?>

<script src="../assets/scripts.js"></script>
</body>
</html>